package vilagtalan_virologusok;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Random;

/**
 * Vezeti a játékot, Létrehozza a játékteret és a virológusokat.
 * */
public class Jatek {
	/** A virológusokat tartalmazó lista, ennek sorrendjében hívja a játékosokat */
	//private Map<Integer, Virologus> virologusok;
	private Map<String, Virologus> virologusok;

	/** Milyen genetikai kódok vannak a pályán */
	private ArrayList<Agens> kodok;

	/**
	 * Jelenleg soron lévő játékos indexe
	 * */
	private int activeIndex = -1;
	/** A pálya összes mezőjét tartalmazó lista */
	//private Map<Integer, Mezo> palya;
	private Map<String, Mezo> palya;
	/**
	 * Játék konstruktora
	 * */
	public Jatek(){
		virologusok = new HashMap<>();
		palya = new HashMap<>();
		kodok = new ArrayList<>();
	}
	
	/**
	 * A játéktér felépítése, virológusok létrehozása, minden készenlétbe állítása, a játék indítása.
	 * */
	public void startGame(int boardSize, int virologusCount) {
		generateMezok(boardSize);
		boardSzomszed();
		virologusokElhelyez(virologusCount);
	}

	/**
	 * Visszaadja a megfelelő id-jű mezőt
	 * @param i id
	 * @return  a kért mező referenciája
	 * @author Ronald, Ákos
	 */
	public Mezo getMezo(String i) { return palya.get(i);  }

	/**
	 * Visszaadja m mező id-jét.
	 * @param m a keresett mező
	 * @return  a kért mező id-je
	 * @author Ronald
	 */
	public String getMezoId(Mezo m)
	{
		for (Map.Entry<String,Mezo> e : palya.entrySet())
			if(e.getValue() == m)
				return e.getKey();
		return null;
	}
	/**
	 * Létrehoz paraméterben megadott számú mezőt, random típusúakat, random esetleges tartalommal.
	 * @param boardSize Mennyi mező jöjjön létre.
	 */
	public void generateMezok(int boardSize){
		int r1, r2;
		Random rand = new Random();
		for (int i = 0; i < boardSize; ++i){
			r1 = rand.nextInt(4);
			switch (r1){
				case 0:
					palya.put(Integer.toString(i), new Mezo());
					break;
				case 1:
					r2 = rand.nextInt(4);
					switch (r2){
						case 0: Kopeny ko = new Kopeny(); palya.put(Integer.toString(i), new Ovohely(ko)); break;
						case 1: Balta b = new Balta(); palya.put(Integer.toString(i), new Ovohely(b)); break;
						case 2: Zsak zs = new Zsak(); palya.put(Integer.toString(i), new Ovohely(zs)); break;
						case 3: Kesztyu ke = new Kesztyu(); palya.put(Integer.toString(i), new Ovohely(ke)); break;
					}
					break;
				case 2:
					r2 = rand.nextInt(4);
					boolean r3 = rand.nextDouble() > 0.9;
					switch (r2){
						case 0: Vitustanc vi = new Vitustanc(); palya.put(Integer.toString(i), new Labor(vi, r3)); break;
						case 1: Vedo ve = new Vedo(); palya.put(Integer.toString(i), new Labor(ve, r3)); break;
						case 2: Benit be = new Benit(); palya.put(Integer.toString(i), new Labor(be, r3)); break;
						case 3: Felejt f = new Felejt(); palya.put(Integer.toString(i), new Labor(f, r3)); break;
						case 4: Medve m = new Medve(); palya.put(Integer.toString(i), new Labor(m, r3)); break;
					}
					break;
				case 3:
					palya.put(Integer.toString(i), new Raktar());
			}
		}

	}

	/**
	 * A generált mezőkhöz beállítja, hogy egyesek egymás szomszédai legyenek.
	 */
	public void boardSzomszed(){
		Random rand = new Random();
		int r;
		ArrayList<Mezo> szomszedok = new ArrayList<>();
		for (Mezo m : palya.values()){

			for (int i = 0; i < rand.nextInt(palya.size()-1); ++i){
				r = rand.nextInt(palya.size()-1);
				if (!szomszedok.contains(palya.get(r)) && !m.equals(palya.get(r))) {
					szomszedok.add(palya.get(r));
					palya.get(r).getSzomszedok().add(m);
				}
			}
			m.set_szomszedok(szomszedok);
		}
	}

	/**
	 * Paraméterben megadott számú virológust generál és elhelyezi a pályán véletlenszerűen.
	 * @param virologusCount
	 */
	public void virologusokElhelyez(int virologusCount){
		Random rand = new Random();
		int r;
		for (int i = 0; i < virologusCount; ++i){
			r = rand.nextInt(palya.size());
			Virologus v = new Virologus(palya.get(r));
			virologusok.put(Integer.toString(i), v);
		}
	}
	
	/**
	 * Következő sorra kerülő játékost kiválasztja
	 * @author safar
	 * */
	public void kovJatekos() {
		activeIndex = (activeIndex + 1) % virologusok.size();
		ArrayList<Virologus> virologusList = new ArrayList<Virologus>(virologusok.values());
		virologusList.get(activeIndex).tick();
	}
	
	/** Lekérdezi a virológus, hogy az őáltala ismert kódok száma vajon megegyezik-e az összes kód számával. */
	public boolean nyerte_e(int i) {
		return i == kodok.size();
	}

	/**
	 * Ha meghal egy virológus, eltávolítjuk a virológusok listából, többé már nem kerül sorra.
	 * A halott virológus "teste" ott marad a pályán, lehet rá kenni ágenst stb.
	 * @param virologus amelyik virológus meghal
	 * @author Vesztergombi
	 */
	public void virologusMeghal(Virologus virologus){
		if (virologusok.containsValue(virologus)) {
			virologusok.values().remove(virologus);
		}
	}


	/**
	 * Hozzáad egy virológust a megadott id-vel a megadott mezőre. A newvir parancshoz szükséges.
	 * @param vir_id virológus azonosítója
	 * @param field_id mező azonosítója
	 * @param has_matter ha true, akkor max anyaga van, ha false, akkor nincs anyaga.
	 */
	public void addVirologus(String vir_id, String field_id, boolean has_matter){
		Virologus v = new Virologus(palya.get(field_id));
		virologusok.put(vir_id, v);
		if (!has_matter){
			Anyag a = v.getAnyag();
			a.csokkent(a.mennyi());
		}
	}


	/**
	 * Szomszédossá teszünk két mezőt.
	 * @param field_id Egyik mező
	 * @param neighbour_id Másik mező
	 */
	public void addFieldNeighbour(String field_id, String neighbour_id){
		Mezo m1 = palya.get(field_id);
		var szomszedok1 = m1.getSzomszedok();
		szomszedok1.add(palya.get(neighbour_id));
		Mezo m2 = palya.get(neighbour_id);
		var szomszedok2 = m2.getSzomszedok();
		szomszedok2.add(palya.get(field_id));

	}

	public enum FieldType{
		MEZO,
		OVOHELY,
		LABOR,
		RAKTAR
	}

	public boolean compareAgn(Agens agn1, Agens agn2){
		return agn1.getName() == agn2.getName();
	}

	public boolean containsAgn(ArrayList<Agens> agnList, Agens agn){
		boolean ret = false;
		for (Agens ag : agnList)
			if (compareAgn(ag, agn)) ret =true;
		return ret;
	}

	/**
	 * Hozzaad egy uj mezot a palyahoz
	 * @param field_id A mezo leendo azonositoja
	 * @param field_type A mezo tipusa (0: Mezo, 1: Ovohely, 2: Labor, 3: Raktar)
	 * @param equipment A mezon talalhato vedofelsz (csak ovohely)
	 * @param isBear Fertoz e medvevirussal (csak labor)
	 * @param code A mezon talalhato kod (csak labor)
	 */
	public void addField(String field_id, FieldType field_type, Vedofelsz equipment, boolean isBear, Agens code){
		//switch (FieldType.values()[field_type]){
		switch (field_type){
			case MEZO:
				Mezo m = new Mezo();
				palya.put(field_id, m);
				if (code != null && !containsAgn(kodok, code))
					kodok.add(code);
				break;
			case OVOHELY:
				Ovohely ovo = new Ovohely(equipment);
				palya.put(field_id, ovo);
				if (code != null && !containsAgn(kodok, code))
					kodok.add(code);
				break;
			case LABOR:
				Labor l = new Labor(code, isBear);
				palya.put(field_id, l);
				if (code != null && !containsAgn(kodok, code))
					kodok.add(code);
				break;
			case RAKTAR:
				Raktar r = new Raktar();
				palya.put(field_id, r);
				if (code != null && !containsAgn(kodok, code))
					kodok.add(code);
				break;
		}
	}

	/**
	 * Torol egy mezot a palyarol
	 * @param field_id a torlendo mezo azonositoja
	 */
	public void removeField(Integer field_id){

	}

	/**
	 * Visszaadja az adott azonositoval rendelkezo virologust.
	 * @param vir_id A virologus id-ja
	 * @return Az adoot id-jű virologus referenciaja
	 */
	public Virologus getVirologus(String vir_id){ return virologusok.get(vir_id);}

	/**
	 * Visszaadja a soron levo virologus id-jet, ha mar megy a jatek (egyebkent nullt)
	 * @return
	 */
	public String getActiveVirologusID(){//TODO: Implementacio

		if (activeIndex == -1) return null;
		return new ArrayList<String>(virologusok.keySet()).get(activeIndex);
	}

	/**
	 * Visszaadja a parameterkent kapott virologus objektum azonositojat
	 * @param v
	 * @return
	 * @author sisak
	 */
	public String getVirologusID(Virologus v){
		for (Map.Entry<String,Virologus> e : virologusok.entrySet())
			if(e.getValue() == v)
				return e.getKey();
		return null;
	}
}
