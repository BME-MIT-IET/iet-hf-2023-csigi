package vilagtalan_virologusok;
import java.lang.reflect.Field;
import java.util.*;


/**
 * A "Proto" osztály felelőssége, hogy a tesztek elvégződjenek.
 * Itt történik az osztályok példányosítása, tesztek futtatása
 *
 * @author  everyone
 */
public class Proto {
    private interface Command{void Run(String[] args);};
    private static Map<String, Command> commands;
    private static Jatek jatek;

    public static final int benalepes_priority = 30;
    public static final int medvelepes_priority = 25;

    public static boolean random = true;
    private static boolean started = false; //TODO: Új játéknál állítsuk át true-ra


    /**
     * Belepesi pont, init + parancsertelmezo
     * A parancsertelmezo minden inputot kisbetusit!!!
     * @param args
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        boolean next = true;
        jatek = new Jatek();

        String[] input;
        Command currentcommand;

        commands = new HashMap<>();
        commands.put("newvir", Proto::newvir);
        commands.put("nextplayer", Proto::nextPlayer);
        commands.put("showngh", Proto::showngh);
        commands.put("addngh", Proto::addngh);
        commands.put("addlabor", Proto::addlabor);
        commands.put("addraktar", Proto::addraktar);
        commands.put("addfield", Proto::addfield);
        commands.put("removefield", Proto::removefield);
        commands.put("listcodes", Proto::listcodes);
        commands.put("ismedve", Proto::ismedve);
        commands.put("showmatter", Proto::showmatter);
        commands.put("dropequipment", Proto::dropequipment);
        commands.put("addovohely", Proto::addovohely);
        commands.put("newgame", Proto::newgame);
        commands.put("load", Proto::load);
        commands.put("save", Proto::save);
        commands.put("move", Proto::move);
        commands.put("useagn", Proto::useagn);
        commands.put("attack", Proto::attack);
        commands.put("useaxe", Proto::useaxe);
        commands.put("getcode", Proto::getcode);
        commands.put("getmatter", Proto::getmatter);
        commands.put("getequipment", Proto::getequipment);
        commands.put("listeq", Proto::listeq);
        commands.put("listagn", Proto::listagn);
        commands.put("isrand", Proto::isrand);
        commands.put("listngh", Proto::listngh);
        commands.put("help", Proto::help);


        while (next && in.hasNextLine()) {
            input = in.nextLine().toLowerCase(Locale.ROOT).split(" ");
            if (input.length == 0 || input[0].length() == 0) {
                System.out.println();
            } else {
                if (input[0].compareTo("exit") == 0) {
                    next = false;
                    continue;
                }

                currentcommand = commands.get(input[0]);
                if (currentcommand != null)
                    currentcommand.Run(input);
                else
                    System.out.println("Command doesn't exist: " + input[0]);
            }
        }
        System.out.println(""); //breakpointnak a végére
    }

    public static void newvir(String[] args){
        if(args == null || args.length < 4) {System.out.println("Virologist creation failed: not enough arguments"); return;}

        String vir_id = null;
        String field_id = null;
        try {
            vir_id = args[1];
            field_id = args[2];
        } catch (NumberFormatException e) {
            System.out.println("Virologist creation failed: bad argument");
            return;
        }

        boolean hasmatter = Boolean.parseBoolean(args[3]);

        jatek.addVirologus(vir_id, field_id, hasmatter);
        jatek.getVirologus(vir_id).setJatek(jatek);
        System.out.println("virologist creation successful");
    }

    public static void nextPlayer(String[] args){
        started = true;
        jatek.kovJatekos();
            //jatek.startGame(10, 5);
        if(jatek.getVirologus(jatek.getActiveVirologusID()).isBena())
        {
            System.out.println("next player is " + jatek.getActiveVirologusID() + ", who is paralyzed");
            return;
        }
        System.out.println("next player is " + jatek.getActiveVirologusID() + ", neighbours:");
        for (Mezo m : jatek.getVirologus(jatek.getActiveVirologusID()).getMostMezo().getSzomszedok()){
            System.out.println("\t" + jatek.getMezoId(m));
        }
    }

    public static void showngh(String[] args){
        if(args == null || args.length < 2) {System.out.println("Not enough arguments"); return;}

        try {
            String field_id = args[1];
            Mezo m = jatek.getMezo(field_id);
            for(int i = 0; i < m.getSzomszedok().size(); ++i)
                System.out.print(jatek.getMezoId(m.getSzomszedok().get(i)) + ", ");
            System.out.println();
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return;
        }
    }

    public static void addngh(String[] args){
        if(args == null|| args.length < 3){System.out.println("Not enough arguments"); return; }

        String field_id = null;
        String neighbour_id = null;
        try {
            field_id = args[1];
            neighbour_id = args[2];
        } catch (Exception e) {
            System.out.println("Failed: bad argument");
            return;
        }

        if(field_id.compareTo(neighbour_id) == 0){
            System.out.println("Failed: equal arguments");
            return;
        }

        jatek.addFieldNeighbour(field_id, neighbour_id);
        System.out.println(field_id + " has new neighbour: " + neighbour_id);
    }

    public static void addlabor(String[] args){
        if(args == null || args.length < 4){System.out.print("Failed: not enough arguments"); return;}

        String field_id = null;
        try{
            field_id = args[1];
        }
        catch(NumberFormatException e){
            System.out.println("Failed: bad argument (id is NaN)");
        }

        boolean isBear = Boolean.parseBoolean(args[2]);

        Agens kod = null;
        switch(args[3]) {
            case ("felejt"):
                kod = new Felejt();
                break;
            case ("vedo"):
                kod = new Vedo();
                break;
            case ("benit"):
                kod = new Benit();
                break;
            case ("vitus"):
                kod = new Vitustanc();
                break;
            default:
                System.out.println("Failed: invalid code");
                return;
        }

        jatek.addField(field_id, Jatek.FieldType.LABOR,null, isBear, kod);

        System.out.println("new labor created:\n\tid: "+field_id+"\n\thas bear: "+isBear+"\n\tcode: "+args[3]);
    }

    public static void addraktar(String[] args){
        if(args == null || args.length < 2){System.out.println("Failed: not enough arguments"); return;}

        String field_id = null;
        try{
            field_id = args[1];
        } catch(NumberFormatException e){
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }

        jatek.addField(field_id, Jatek.FieldType.RAKTAR, null, false, null);
        System.out.println("new raktar created:\n\tid: "+field_id);
    }

    public static void addfield(String[] args){
        if(args == null || args.length < 2){System.out.println("Failed: not enough arguments"); return;}

        String field_id = null;
        try{
            field_id = args[1];
        } catch(NumberFormatException e){
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }

        jatek.addField(field_id, Jatek.FieldType.MEZO, null, false, null);
        System.out.println("new mezo created:\n\tid: "+field_id);
    }

    public static void removefield(String[] args){
        if(args == null || args.length < 2){System.out.println("Failed: not enough arguments"); return;}

        Integer field_id = null;
        try{
            field_id = Integer.parseInt(args[1]);
        } catch(NumberFormatException e){
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }

        jatek.removeField(field_id);
        System.out.println(field_id + "field removal: success");
    }

    public static void listcodes(String[] args){
        if(args == null || args.length < 2){System.out.println("Failed: not enough arguments"); return;}

        String vir_id = null;
        try{
            vir_id = args[1];
        } catch(NumberFormatException e){
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }
        Virologus v = jatek.getVirologus(vir_id);
        if(v == null){System.out.println("Failed: virologist doesn't exist"); return;}

        System.out.println("known agents of "+vir_id+":");
        for(Agens a: v.getIsmertKodok()){
            System.out.println("\t"+a.getName());
        }

    }

    public static void ismedve(String[] args){
        if(args == null|| args.length < 2){System.out.println("Failed: not enough arguments"); return;}

        String vir_id = null;
        try {
            vir_id = args[1];
        } catch (NumberFormatException e) {
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }

        Virologus v = jatek.getVirologus(vir_id);
        if(v == null){System.out.println("Failed: virologist doesn't exist"); return;}

        System.out.println(vir_id+ " is medve: " + v.isMedve());
    }

    public static void showmatter(String[] args){
        if(args == null|| args.length < 2){System.out.println("Failed: not enough arguments"); return;}

        String vir_id = null;
        try {
            vir_id = args[1];
        } catch (NumberFormatException e) {
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }

        Virologus v = jatek.getVirologus(vir_id);
        if(v == null){System.out.println("Failed: virologist doesn't exist"); return;}

        System.out.println("matter amount for "+vir_id+": "+v.getAnyag().mennyi());
    }

    public static void dropequipment(String[] args){
        System.out.print("dropping ");

        if(args == null || args.length < 2){System.out.println("Failed: Not enough arguments"); return;}
        System.out.print(args[1]+":");
        Vedofelsz type = null;

        switch(args[1]){
            case("kesztyu"):
                type = new Kesztyu();
                break;
            case("kopeny"):
                type = new Kopeny();
                break;
            case("zsak"):
                type = new Zsak();
                break;
            case("balta"):
                type = new Balta();
                break;
            default:
                System.out.println("Failed: Vedofelsz of type "+args[1]+" doesn't exist");
                return;
        }

        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);
        ArrayList<Vedofelsz> vdfsz = v.getVedofelszList();

        for(Vedofelsz a: vdfsz){
            if(a.getClass() == type.getClass()){
                v.removeVedofelsz(a);
                System.out.println("Successful");
                return;
            }
        }
        System.out.println("Failed: Virologus doens't have this type of Vedofelsz");
    }

    public static void addovohely(String[] args){
        if(args == null || args.length < 3){System.out.println("Failed: not enough arguments"); return;}

        String field_id = null;
        try{
            field_id = args[1];
        } catch(NumberFormatException e){
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }
        Vedofelsz vedfelsz = null;
        switch(args[2]){
            case("kesztyu"):
                vedfelsz = new Kesztyu(); break;
            case("zsak"):
                vedfelsz = new Zsak(); break;
            case("kopeny"):
                vedfelsz = new Kopeny(); break;
            case("balta"):
                vedfelsz = new Balta(); break;
            default:
                System.out.println("Failed: invalid equipment");
                return;
        }

        jatek.addField(field_id, Jatek.FieldType.OVOHELY, vedfelsz, false, null);
        System.out.println("new ovohely created:\n\tid: "+field_id+"\n\tequipment: " + args[2]);
    }


    /**
     * Elindít egy új játékot, létrehozza hozzá a pályát, illetve hozzáadja a játékosokat.
     * A pálya mérete a játékosok számától függ, amennyiben random módban van a játék.
     * Amennyiben determinisztikus módban vagyunk, a pályát mi kell létrehozzuk.
     * @param args 0. eleme a játékosok száma
     */
    public static void newgame(String[] args){
        if (!random){
            System.out.println("new map: failed random is off");
            return;
        }
        if(args == null|| args.length < 2){System.out.println("Failed: not enough arguments"); return;}
        jatek = new Jatek();
        try {
            jatek.startGame(Integer.parseInt(args[1])*3, Integer.parseInt(args[1]));
            System.out.println("new map: succesful\nplayer number: " + Integer.parseInt(args[1]));
            started = true;
        } catch (Exception e) {
            System.out.println("new map: failed");
        }
    }

    public static void load(String[] args){//TODO
    }

    public static void save(String[] args){//TODO
    }


    public static void move(String[] args){
        System.out.print("move to ");
        if(args == null || args.length < 2){System.out.println("Failed: not enough arguments"); return;}

        String neigh_id = null;
        try{neigh_id = args[1];}
        catch(NumberFormatException e){System.out.println("Failed: bad argument (id is NaN)"); return;}
        System.out.print(neigh_id+": ");

        String vir_id = jatek.getActiveVirologusID();
        if(vir_id== null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);

        //Lepes megvalositasa itt:
        //Az eppen lepo virologus a v, a mezo id-je pedig neigh_id valtozoban van
        /*if (v.isMedve()){
            System.out.println("failed medve vagy");
        } else if (v.getAgensek().contains(Vitustanc.class)){
            System.out.println("failed vitustanc van");
        } else {*/
            try {
                Mezo m = jatek.getMezo(neigh_id);
                int index = v.getMostMezo().getSzomszedok().indexOf(m);
                if (index == -1){
                    System.out.println("failed: nincs ilyen szomszéd");
                    return;
                }
                boolean sik = v.lep(index);
                if(sik)
                {
                    if(v.isBena())
                        System.out.println("failed Bena active");
                    else if(v.isMedve())
                        System.out.println("failed medve active, moved to " + jatek.getMezoId(v.getMostMezo()));
                    else if (sik && jatek.getMezoId(v.getMostMezo()).compareTo(neigh_id) == 0)
                        System.out.println("successful");
                    else
                        System.out.println("failed vitus active, moved to " + jatek.getMezoId(v.getMostMezo()));
                }
                else
                    System.out.println("failed: a körben már léptél");

            } catch (Exception e) {
                System.out.println("failed: ismeretlen");
            }
        //}

    }


    public static void useagn(String[] args){
        System.out.print("using agent on ");
        if(args == null|| args.length < 3){System.out.println("Failed: not enough arguments"); return;}

        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);


        try {
            vir_id = (args[2].equals("0")) ? vir_id : args[2];
        } catch (NumberFormatException e) {
            System.out.println("Failed: bad argument"); return;
        }

        System.out.print(vir_id+": ");
        Virologus v2 = jatek.getVirologus(vir_id);
        if(v2 == null){System.out.println("Failed: Virologist by this id doesn't exist"); return;}

        //Ellenorzi, hogy letezik e
        Agens agns = null;
        for(Agens ag : v.getIsmertKodok()){
            if(Objects.equals(ag.getName(), args[1])){
                agns = ag; break;       // duplicate nem kell
            }
        }
        if(agns == null){System.out.println("Failed: Virologist doesn't know the code for this agent"); return;}

        if (v.kendMeg(v2, agns)){
            System.out.println("successful");
        } else{
            System.out.println("failed");
        }
    }

    public static void attack(String[] args){
        System.out.print("attacking ");
        if(args == null|| args.length< 2){System.out.println("Failed: not enough arguments"); return;}
        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);

        try {
            vir_id = args[1];
        } catch (NumberFormatException e) {
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }
        System.out.print(vir_id+":");
        Virologus v2 = jatek.getVirologus(vir_id);
        if(v2 == null){System.out.println("Failed: Virologus by this id doesn't exist"); return;}

        //Ellenorzi, hogy egy mezon allnak e
        boolean sameMezo = false;
        for(Virologus vi: v.getMostMezo().ittLevok()){
            if(vi == v2){
                sameMezo = true; break;
            }
        }
        if(!sameMezo){System.out.println("Failed: Virologists have to be standing on the same field to attack"); return;}

        v.tamaddMeg(v2);
        if(v2.isBena())
            System.out.println("successful");
        else
            System.out.println("failed reason: celpont nem benult");
    }

    public static void useaxe(String[] args){
        System.out.print("axeing ");
        if(args == null|| args.length< 2){System.out.println("Failed: not enough arguments"); return;}
        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);

        try {
            vir_id = args[1];
        } catch (NumberFormatException e) {
            System.out.println("Failed: bad argument (id is NaN)");
            return;
        }
        System.out.print(vir_id+":");
        Virologus v2 = jatek.getVirologus(vir_id);
        if(v2 == null){System.out.println("Failed: Virologus by this id doesn't exist"); return;}

        //Ellenorzi, hogy egy mezon allnak e
        boolean sameMezo = false;
        for(Virologus vi: v.getMostMezo().ittLevok()){
            if(vi == v2){
                sameMezo = true; break;
            }
        }
        if(!sameMezo){System.out.println("Failed: Virologists have to be standing on the same field to attack"); return;}

        if(!v2.isMedve()) { System.out.println("failed target not a bear"); return;}

        //Ellenorzi, hogy van e nem csorba balta
        for(Vedofelsz vdf: v.getVedofelszList()){
            if(vdf instanceof Balta && !((Balta) vdf).isCsorba()){
                ((Balta)vdf).use(v2);
                System.out.println("successful");
                return;
            }
        }
        System.out.println("Failed: virologist doesn't have any useable axes");
    }

    public static void getcode(String[] args){
        System.out.print("getting code: ");
        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);
        if (v.tapogasdLe()){
            System.out.println("successful");
        } else{
            System.out.println("failed");
        }
        if (jatek.nyerte_e(jatek.getVirologus(vir_id).getIsmertKodok().size())) {
            System.out.println(vir_id + " won the game!!");
        }
    }

    public static void getmatter(String[] args){
        System.out.print("getting matter: ");
        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);
        int old_amount = v.getAnyag().mennyi();
        v.addAnyag();
        int new_amount = v.getAnyag().mennyi();
        if(old_amount == new_amount){
            System.out.println("failed");
        }
        else{ System.out.println("successful");}
    }

    public static void getequipment(String[] args){
        System.out.print("getting equipment: ");
        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        Virologus v = jatek.getVirologus(vir_id);
        if (v.getVedofelszList().size() >= 3){
            System.out.println("failed reason: nincs eleg hely felszerelesnek");
        } else {
            if(v.veddFelVedofelsz())
                System.out.println("successful");
            else
                System.out.println("failed");
        }
    }

    public static void listeq(String[] args){
        System.out.print("current equipment of ");
        if(args == null||args.length < 2){System.out.println("Failed: not enough arguments"); return;}
        String vir_id = null;
        try{vir_id = args[1];}
        catch(NumberFormatException e){System.out.println("Failed: bad argument (id is NaN)"); return;}
        System.out.println(vir_id+":");

        Virologus v; if((v= jatek.getVirologus(vir_id)) == null){System.out.println("Failed: Virologist by this id doesn't exist"); return;}
        ArrayList<Vedofelsz> vdfsz = v.getVedofelszList();
        for(int i = 0; i < vdfsz.size(); ++i){
            System.out.println("\t" + (i+1) + ": " + vdfsz.get(i).getName());
        }

    }

    public static void listagn(String[] args){
        System.out.print("current agents on ");
        if(args == null|| args.length < 2){System.out.println("Failed: not enough arguments"); return;}
        System.out.println(args[1]+":");

        String vir_id = null;
        try{ vir_id = args[1];}
        catch(NumberFormatException e){System.out.println("Failed: bad argument (id is NaN)"); return;}

        Virologus v = jatek.getVirologus(vir_id);
        if(v == null){System.out.println("Failed: Virologus by this id doesn't exist"); return;}
        ArrayList<Agens> agns = v.getAgensek();
        for(Agens ag: agns){
            System.out.println("\t"+ag.getName());
        }
    }

    public static void listngh(String[] args){
        System.out.print("curernt neighbours of ");
        String vir_id = jatek.getActiveVirologusID();
        if(vir_id == null){System.out.println("Failed: the game hasn't started yet"); return;}
        System.out.println(vir_id+" :");

        Virologus v = jatek.getVirologus(vir_id);
        Mezo m = v.getMostMezo();
        ArrayList<Virologus> vl = m.ittLevok();
        for(Virologus v1: vl){
            System.out.println("\t"+jatek.getVirologusID(v1));
        }
    }

    public static void isrand(String[] args){
        System.out.print("randomness set to ");
        if(args == null || args.length < 2){System.out.println("Failed: not enough arguments"); return;}
        boolean setTo = Boolean.parseBoolean(args[1]);
        random = setTo;
        System.out.println(setTo ? "on" : "off");
    }

    public static void help(String[] args){
        String output =
                "newgame [player_num]\tElindit egy jatekot, letrehozza a palyat, hozzaadja a virologusokat\n" +
                        "load [file_name]\tEgy elore beallitott parancs sorozatot tolt be a jatek a megadott fajlbol\n" +
                        "save [file_name]\tA lefutas kimenetet elmenti a megadott fajlba\n" +
                        "move [neigh_id]\tAz aktiv jatekos megkiserel elmozdulni az adott mezore\n" +
                        "useagn [agn_type] [target_vir]\tAz aktiv jatekos megkiserel megkenni valakit egy adott agensevel\n" +
                        "attack [target_vir]\tAz aktiv jatekos megprobalja kirabolni a megcelzott virologust\n" +
                        "useaxe [target_vir\tA jatekos baltaval leuti a kivalasztott virologust\n" +
                        "getcode\tA jelen mezon levo kod letapogatasa\n" +
                        "getmatter\tA jelen mezon levo anyag felvetele\n" +
                        "getequipment\tA jelen mezon levo felszereles felvetele\n" +
                        "listeq [vir_id]\tAz azonositoval adott jatekosnal levo felszerelesek kilistazasa\n" +
                        "listagn [vir_id\tAz adott jatekoson aktiv hatassal levo agensek kilistazasa\n" +
                        "listcodes [vir_id]\tAz adott virologus altal megtanult agenseket listazza ki\n" +
                        "listngh\tA jatekossal egy mezon allo virologusok kilistazasa\n" +
                        "isrand\tA jatek random reszeinek ki/bekapcsolasa\n" +
                        "newvir [vir_id] [field_id] [has_matter]\tEgy uj virologust hoz letre egy adott mezon\n" +
                        "nextplayer\tBefejezi a soron lev jatekos koret\n" +
                        "showngh [field_id]\tAz adott mezo szomszedait kilistazza\n" +
                        "addngh [field_id] [new_ngh_id]\tAz adott mezonek ad egy uj szomszedot\n" +
                        "addlabor [field_id] [is_bear] [code]\tHozzaad egy uj labor tipusu mezot a palyahoz\n" +
                        "addraktar [field_id]\tHozzaad egy uj raktar tipusu mezot a palyahoz\n" +
                        "addovohely [field_id] [equipment]\tHozzaad egy uj ovohely tipusu mezot a palyahoz\n" +
                        "addfield [field_id]\tHozzaad egy uj mezot a palyahoz\n" +
                        "removefield [field_id]\tTorol egy letezo mezot\n" +
                        "liscodes [vir_id]\tListazza a virologus altal ismert agenseket\n" +
                        "ismedve [vir_id]\tKiirja, hogy az adott virologus medve e\n" +
                        "showmatter [vir_id]\tAz adott virologus anyaganak allapotat mutatja\n" +
                        "dropequipment [equipment]\tAz aktiv jatekos eldobja az adott felszerelest\n";
        System.out.println(output);
    }
}