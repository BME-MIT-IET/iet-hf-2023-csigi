package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**A védőfelszerelések absztrakt ősosztálya. */
public abstract class Vedofelsz extends Hatas implements Leptetheto {
    Virologus tulaj;

    /**
     * Védőfelszerelés létrehozása, és a tulaj hozzáadása
     * @param v a virológus aki a tulaj lesz
     * @author safar
     * */
    public void begin(Virologus v) {
        Skeleton.tmpWriteOutIn("Vedofelsz:begin start");
        tulaj = v;
        Skeleton.tmpWriteOutOut("Vedofelsz:begin end");
    }

    /**
     * Védőfelszerelés eltávolítása a tulajtól
     * @author safar
     * */
    public void end() {
        Skeleton.tmpWriteOutIn("Vedofelsz:end start");
        tulaj.removeVedofelsz(this);
        Skeleton.tmpWriteOutOut("Vedofelsz:end end");
    }
}
