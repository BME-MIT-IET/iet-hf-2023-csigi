package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/** Óvóhely típusú mezőt reprezentáló osztály*/
public class Ovohely extends Mezo {

	/**
	 * Konstruktor
	 * @param vdf A mezőn elhelyezendő védőfelszerelés
	 */
	public Ovohely(Vedofelsz vdf){
		Skeleton.tmpWriteOutIn("Ovohely:ctor start");

		vedofelsz = vdf;

		Skeleton.tmpWriteOutOut("Ovohely:ctor end");
	}

	/** A mezőn lévő védőfelszerelés */
	private Vedofelsz vedofelsz;
	
	/** Odaadja a mezőn lévő védőfelszerelét (a mezőről törlődik)
	 * @return A védőfelszerelés */
	public Vedofelsz felveszVedofelsz() {
		Skeleton.tmpWriteOutIn("Ovohely:felveszVedofelsz start");

		Vedofelsz vdf = vedofelsz;
		vedofelsz = null;

		Skeleton.tmpWriteOutOut("Ovohely:felveszVedofelsz end");
		return vdf;
	}
}
