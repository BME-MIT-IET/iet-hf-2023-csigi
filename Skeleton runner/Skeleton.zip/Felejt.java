package vilagtalan_virologusok;/*
* Description
*
*  @author Ákos
*/


import java.util.ArrayList;

/**
 * Olyan ágenst valósít meg, melynek hatására a virológus, akire rákenik elfelejti minden addig megtanult genetikai kódját.
 * */
public class Felejt extends Agens {
	/** Mennyi anyag kell az elkészítéshez */
	private int ar;
	
	/**  */
	public void begin(Virologus v) {
		Skeleton.tmpWriteOutIn("Felejt:begin start");
		ArrayList<Agens> ismertek = new ArrayList<>();
		ismertek = v.getIsmertKodok();
		for(Agens a: ismertek){
			v.torolAgens(a);
		}
		Skeleton.tmpWriteOutOut("Felejt:begin end");
	}
	
	/** */
	public Agens duplicate()
	{
		Skeleton.tmpWriteOutIn("Felejt:duplicate start");
		Skeleton.tmpWriteOutOut("Felejt:duplicate end");
		return new Felejt();
	}
}
