package vilagtalan_virologusok;


/**
 * Ez egy olyan Lepes megvalósítás, amely a bénultság állapotában való
 * lépést implementálja. (semmit) Priorítása > Vitustancolo
 *
 *
 * @author Rádai Ronald
 */
public class Bena extends Lepes
{
	/**
	 * Visszaadja az adott lépés prioritását.
	 * @return Prioritás
	 */
	@Override
	public int getPriority() { Skeleton.tmpWriteOutIn("Lepes:getPriority start"); Skeleton.tmpWriteOutOut("Lepes:getPriority end"); return 30; }

	/**
	 * Bénult állapotbani lépés megvalósítása.
	 * -1-et ad vissza, mint hogy nem léphet
	 * @param to i. mező, ahova a játékos szeretne lépni
	 * @param n a jelenlegi mező szomszédjainak a számossága
	 * @return A kiválasztott lépés (to értéke)
	 */
	@Override
	public int lepes(int to, int n)
	{
		Skeleton.tmpWriteOutIn("Bena:Lepes start");
		Skeleton.tmpWriteOutOut("Bena:Lepes end");
		return -1;
	}
}
