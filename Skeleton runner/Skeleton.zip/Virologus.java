package vilagtalan_virologusok;

import java.util.ArrayList;


/**
 * A játékos által irányítható karakter. Feladata, hogy mezőről mezőre lépjen,
 * genetikai kódokat tanuljon meg a játék megnyeréséhez, védőfelszereléseket
 * szedjen fel, ágenseket alkalmazzon magára vagy más virológusokra, kiraboljon
 * más virológusokat.
 */
public class Virologus implements Leptetheto {
    private final Lepesmgr lepesmgr = new Lepesmgr();

    /**
     * sima konstruktor
     */
    public Virologus() {
        Skeleton.tmpWriteOutIn("Virologus:ctor start");
        Skeleton.tmpWriteOutOut("Virologus:ctor end");
    }

    /**
     * Konstruktor, egyből a megadott mezőre teszi a virológust
     * @param m A mező ahová tenni szeretnénk
     * @author sisak
     */
    public Virologus(Mezo m){
        Skeleton.tmpWriteOutIn("Virologus:ctor start");

        mostMezo = m;
        szomszedok = mostMezo.ralep(this);

        Skeleton.tmpWriteOutOut("Virologus:ctor end");
    }

    /**
     * konstruktor rablos es leptetos tesztekhez
     *
     * @author safar
     */
    public Virologus(boolean bena, ArrayList<Vedofelsz> vedo, ArrayList<Agens> agns) {
        Skeleton.tmpWriteOutIn("Virologus:ctor start");
        if (bena) addLepes(new Bena());
        vedofelszek = vedo;
        agensek = agns;
        Skeleton.tmpWriteOutOut("Virologus:ctor end");
    }


    /**
     * Konstruktor a felejtős tesztesethez
     * @param ismert_agensek Ezeket az Ágenseket fogja tudni fejből a Virologus
     * @author Ákos
     */
    public Virologus(ArrayList<Agens> ismert_agensek)
    {
        Skeleton.tmpWriteOutIn("Virologus:ctor start");
        ismertKodok = ismert_agensek;
        Skeleton.tmpWriteOutOut("Virologus:ctor end");
    }

    /**
     * Az a mező ahol jelenleg áll a virológus
     */
    private Mezo mostMezo;

    /**
     * A virológusra ható ágensek
     */
    private ArrayList<Agens> agensek = new ArrayList<Agens>();

    /**
     * A virológusnál lévő védőfelszerelések
     */
    private ArrayList<Vedofelsz> vedofelszek = new ArrayList<Vedofelsz>();

    /**
     * A virológus anyagát kezelő osztály
     */
    private Anyag anyag = new Anyag();

    /**
     * A virológus által ismert genetikai kódok
     */
    private ArrayList<Agens> ismertKodok = new ArrayList<>();

    /**
     * A virológus alatt lévő mező szomszédjai
     */
    private ArrayList<Mezo> szomszedok = new ArrayList<>();

    /**
     * Megtámadtak, ennek a lekezelését hajtja végre a függvény
     *
     * @param tamado a virológus, aki megtámadott
     * @return a másik által elrabolt védőfelszerelések listája
     * @author safar
     */
    public ArrayList<Vedofelsz> megtamad(Virologus tamado) {
        Skeleton.tmpWriteOutIn("Virologus:megtamad start");
        if (lepesmgr.bena()) {
            ArrayList<Vedofelsz> vfsz_copy = new ArrayList<Vedofelsz>();
            vfsz_copy.addAll(vedofelszek);

            for (int i = vedofelszek.size() - 1; i >= 0; i--)
                vedofelszek.get(i).end();

            anyag.kirabolnak(tamado);
            Skeleton.tmpWriteOutOut("Virologus:megtamad end");
            return vfsz_copy;
        } else {
            Skeleton.tmpWriteOutOut("Virologus:megtamad end");
            return null;
        }
    }

    /**
     * Egy másik virológus megtámadását kezdeményezzük
     *
     * @param v a virológus akit megtámadjunk
     * @author safar
     */
    public void tamaddMeg(Virologus v) {
        Skeleton.tmpWriteOutIn("Virologus:tamaddMeg start");
        ArrayList<Vedofelsz> vfsz = v.megtamad(this);

        if (vfsz != null) {
            for (Vedofelsz fsz : vfsz) {
                fsz.begin(this);
            }
            vedofelszek.addAll(vfsz);
        }

        Skeleton.tmpWriteOutOut("Virologus:tamaddMeg end");
    }

    /**
     * Kód letapogatását kezdeményező függvény
     *
     * @author sisak
     */
    public void tapogasdLe() {
        Skeleton.tmpWriteOutIn("Virologus:tapogasdLe start");

        Agens agns = mostMezo.letapogat();
        if (agns != null && !ismertKodok.contains(agns))
            ismertKodok.add(agns);

        Skeleton.tmpWriteOutOut("Virologus:tapogasdLe end");
    }

    /**
     * A védőfelszerelés felvételét kezdeményező függvény
     *
     * @author sisak
     */
    public void addVedofelsz() {
        Skeleton.tmpWriteOutIn("Virologus:addVedofelsz start");

        Vedofelsz vdflsz = mostMezo.felveszVedofelsz();
        addVedofelsz(vdflsz);

        Skeleton.tmpWriteOutOut("Virologus:addVedofelsz end");
    }

    /**
     * Védőfelszerelés hozzáadása az eddigiekhez
     *
     * @param vdflsz A hozzáadni kívánt védőfelszerelés
     * @author Vesztergombi
     */
    public void addVedofelsz(Vedofelsz vdflsz) {
        Skeleton.tmpWriteOutIn("Virologus:addVedofelsz start");

        if (vdflsz != null && vedofelszek.size() < 3) {
            vedofelszek.add(vdflsz);
            vdflsz.begin(this);
        }

        Skeleton.tmpWriteOutOut("Virologus:addVedofelsz end");
    }

    /**
     * Az anyag felvételét kezdeményező függvény
     *
     * @author sisak
     */
    public void addAnyag() {
        Skeleton.tmpWriteOutIn("Virologus:addAnyag start");

        mostMezo.felveszAnyag(this);

        Skeleton.tmpWriteOutOut("Virologus:addAnyag end");
    }


    /**
     * @param v Ki próbál megkenni minket?
     * @param a Mivel próbálnak megkenni minket?
     * @return Kivédtük-e a kenést, megakadályozzuk-e hogy ránk kenjék?
     * @author Ákos
     */
    public boolean megken(Virologus v, Agens a) {
        Skeleton.tmpWriteOutIn("Virologus:megken start");
        //Itt ellenőrzi, hogy van-e olyan cucca ami megakadályozza..
        boolean forbids = false;

        for (Hatas h : agensek) {
            if (h.megkentek(a, v)) {
                forbids = true;
                break;
            }
        }
        for (Hatas h : vedofelszek) {
            if (h.megkentek(a, v)) {
                forbids = true;
                break;
            }
        }

        if (!forbids) {
            a.begin(this);
        }

        Skeleton.tmpWriteOutOut("Virologus:megken end");
        return forbids;
    }

    /**
     * Megken egy virológust egy ágenssel
     * @param v A megkenendő virológus
     * @param a A kenendő ágens
     */
    public void kendMeg(Virologus v, Agens a) {
        Skeleton.tmpWriteOutIn("Virologus:kendMeg start");
        int price = a.getAr();
        if (anyag.csokkent(price)) {
            Agens uj_agens = a.duplicate();
            v.megken(this, uj_agens);
            /*if (v.megken(this, uj_agens)) {
                //a.begin(this);  Nem tudunk különbséget tenni hogy köpeny védi ki és akkor elveszik vagy kesztyűvel védjük ki és akkor visszakenik ránk
            } else {
                a.begin(v);
            }*/
        }
        Skeleton.tmpWriteOutOut("Virologus:kendMeg end");
    }

    /**
     * A virológus léptethető tulajdonaira meghívja a tick függvényt
     *
     * @author safar
     */
    public void tick() {
        Skeleton.tmpWriteOutIn("Virologus:tick start");
        for (Agens agn : agensek)
            agn.tick();
        for (Vedofelsz fsz : vedofelszek)
            fsz.tick();
        Skeleton.tmpWriteOutOut("Virologus:tick end");
    }


    /**
     * Elfelejteti a Agenst a virologussal ha azt már megtanulta
     *
     * @param a az az Agens amit a Virologusnak el kell felejtenie
     */
    public void torolAgens(Agens a) {
        Skeleton.tmpWriteOutIn("Virologus:torolAgens start");
        Skeleton.tmpWriteOutOut("Virologus:torolAgens end");
    }

    /**
     * Végrehajtja a lépést az i. irányba.
     *
     * @param i Amerre lép a virológus
     */
    public void lep(int i) {
        Skeleton.tmpWriteOutIn("Virologus:Lep start");
        int lep = lepesmgr.Lep(i, szomszedok.size());//szomszedok.size());
        Skeleton.tmpWriteOutMsg("Returned value: " + lep);
        if (lep != -1) {
            mostMezo.ellep(this);
            szomszedok = szomszedok.get(lep).ralep(this);
        }
        Skeleton.tmpWriteOutOut("Virologus:Lep end");
    }


    /**
     * Visszaadja a már megismert genetikai kódokat.
     *
     * @return A már megtanult genetikai kódok ArrayList-ben
     */
    public ArrayList<Agens> getIsmertKodok() {
        Skeleton.tmpWriteOutIn("Virologus:getIsmertKodok start");
        Skeleton.tmpWriteOutOut("Virologus:getIsmertKodok end");
        return ismertKodok;
    }

    /**
     * @return A virológus anyagát kezelő osztály
     */
    public Anyag getAnyag() {
        Skeleton.tmpWriteOutIn("Anyag:getAnyag start");
        Skeleton.tmpWriteOutOut("Anyag:getAnyag end");
        return anyag;
    }

    /**
     * Hozzáadunk egy lépésfajtát a virológus által használható lépések közé
     *
     * @param l A hozzáadni kívánt lépés
     */
    public void addLepes(Lepes l) {
        Skeleton.tmpWriteOutIn("Virologus:addLepes start");
        lepesmgr.addLepes(l);
        Skeleton.tmpWriteOutOut("Virologus:addLepes end");
    }

    /**
     * Elveszünk egy lépésfajtát a virológus által használható lépések közül
     *
     * @param l Az eltávolítani kívánt lépés
     */
    public void removeLepes(Lepes l) {
        Skeleton.tmpWriteOutIn("Virologus:removeLepes start");
        lepesmgr.removeLepes(l);
        Skeleton.tmpWriteOutOut("Virologus:removeLepes end");
    }

    /**
     * A megadott védőfelszerelést kiveszi a virológus felszerelései közül
     *
     * @author safar
     */
    public void removeVedofelsz(Vedofelsz v) {
        Skeleton.tmpWriteOutIn("Virologus:removeVedofelsz start");
        if (vedofelszek.contains(v) /*&& v != null*/) {
            vedofelszek.remove(v);
        }
        Skeleton.tmpWriteOutOut("Virologus:removeVedofelsz end");
    }
}
