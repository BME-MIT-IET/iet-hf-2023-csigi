package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**
 * A virológus anyagkészleteit tároló osztály.
 * */
public class Anyag {
	/**Azt jelzi mennyi anyaga van a virológusnak épp most */
	private int mennyiseg;
	
	/** Azt jelzi mennyi a maximális anyagmennyiség, ami a virológusnál lehet*/
	private int maxAnyag;

	/** Az induló anyag mennyiség */
	static int alapMennyiseg = 30;

	/** Az induló maximális anyag mennyiség */
	static int alapMaxAnyag = 100;

	/** Alap konstruktor*/
	public Anyag(){
		mennyiseg = alapMennyiseg;
		maxAnyag = alapMaxAnyag;
	}
	
	/**
	 * Megnöveli az anyagmennyiséget a paraméterben kapott értékkel, maximálva a maximum értékre
	 * */
	public void novel(int mennyi)
	{
		Skeleton.tmpWriteOutIn("Anyag:novel start");
		mennyiseg += mennyi;
		if(mennyiseg > maxAnyag)
		{
			mennyiseg = maxAnyag;
		}
		Skeleton.tmpWriteOutOut("Anyag:novel end");
	}
	
	/**
	 * Csökkenti az anyagmennyiséget a megadott értékkel ha tudja, és visszatér true-val.
	 * Ha nem tudja, nem csökkent semmivel és false-szal tér vissza.
	 * */
	public boolean csokkent(int mennyi)
	{
		Skeleton.tmpWriteOutIn("Anyag:csokkent start");
		boolean enough = Skeleton.tmpAskQuestion("Van elég anyaga?");
		Skeleton.tmpWriteOutOut("Anyag:csokkent end");
		return enough;
	}
	
	/**
	 * Getter az anyagmennyiséghez
	 * */
	public int mennyi()
	{
//		Nem tudom hogy minden egyszerű kis getterhez is kell-e a kiíratás.. - Ákos
//		Skeleton.tmpwriteoutin("Anyag:mennyi start");
//		Skeleton.tmpwriteoutout("Anyag:mennyi end");
		return mennyiseg;
	}
	
	/**
	 * Kirabolnak, vagyis a nálam lévő anyag átlerül a támadóhoz
	 * @param tamado a támadó virológus objektuma
	 * @author safar
	 * */
	public void kirabolnak(Virologus tamado) {
		Skeleton.tmpWriteOutIn("Anyag:kirabolnak start");
		tamado.getAnyag().novel(mennyiseg);
		mennyiseg = 0;
		Skeleton.tmpWriteOutOut("Anyag:kirabolnak end");
	}
	
	/**
	 * Amikor raktárból vesz föl anyagot, a Raktar ezt hívja meg
	 * @author sisak
	  */
	public void raktar() {
		Skeleton.tmpWriteOutIn("Anyag:raktar start");

		mennyiseg = maxAnyag;

		Skeleton.tmpWriteOutOut("Anyag:raktar end");
	}
	
	/** Növeli az anyagfelvevő-képességet a 1,5-szeresére*/
	public void maxNovel()
	{
		Skeleton.tmpWriteOutIn("Anyag:maxNovel start");
		maxAnyag *= 1.5;
		Skeleton.tmpWriteOutOut("Anyag:maxNovel end");
	}
	
	/** Csökkenti az anyagfelvevőképességet a 2/3-ára*/
	public void maxCsokkent()
	{
		Skeleton.tmpWriteOutIn("Anyag:maxCsokkent start");
		maxAnyag *= 2; maxAnyag /= 3;  //Így lesz jól visszacsökkentve az eredeti értékére
		Skeleton.tmpWriteOutOut("Anyag:maxCsokkent end");
	}
}

