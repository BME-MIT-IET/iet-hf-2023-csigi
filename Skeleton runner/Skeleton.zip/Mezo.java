package vilagtalan_virologusok;/*
* Description
*
*  @author
*/


import java.util.ArrayList;

/**
 * A játék mezőit reprezentáló osztály. Mezőkön vannak a virológusok, azonos mezőkön állva találkoznak.
 * A mezők szomszédosak egymással, így adják ki a játékteret.
 * */
public class Mezo {
	/** A mezőn álló virológusok */
	private ArrayList<Virologus> virologusok = new ArrayList<Virologus>();
	
	/** Szomszédos mezők */
	private ArrayList<Mezo> szomszedok = new ArrayList<Mezo>();

	/**
	 * Szomszédok listája
	 * @return A szomszédok listáját adja vissza
	 * @author Vesztergombi
	 */
	public ArrayList<Mezo> getSzomszedok() {
		return szomszedok;
	}

	/**
	 * Mezőn lévők listája
	 * @return Visszaadja a mezőn lévő virológusok listáját
	 * @author Vesztergombi
	 */
	public ArrayList<Virologus> ittLevok() {
		Skeleton.tmpWriteOutIn("Mezo:ittLevok start");
		Skeleton.tmpWriteOutOut("Mezo:ittLevok end");
		return virologusok;
	}

	/**
	 * Fölveszi a rajta lévő virológusok közé
	 * @param v A virológus, aki rálép
	 * @return A szomszédok listája
	 * @author Vesztergombi
	 */
	public ArrayList<Mezo> ralep(Virologus v) {
		Skeleton.tmpWriteOutIn("Mezo:ralep start");
		virologusok.add(v);
		Skeleton.tmpWriteOutOut("Mezo:ralep end");
		return getSzomszedok();
	}

	/**
	 * Szomszédok beállítása
	 * @param sz Szomszédok listája
	 */
	public void  set_szomszedok(ArrayList<Mezo> sz)
	{
		szomszedok = sz;
	}
	
	/**
	 * Akkor hívja meg a virológus, ha ellép a mezőről
	 * @param ki Az ellépő virológus
	 * */
	public void ellep(Virologus ki)
	{
		Skeleton.tmpWriteOutIn("Mezo:ellep start");
		virologusok.remove(this);
		Skeleton.tmpWriteOutOut("Mezo:ellep end");
	}
	
	/**
	 * Megpróbálja letapogatni a genetikai kódot (nem sikerül)
	 * */
	public Agens letapogat() { return null;
	}
	
	/**
	 * Megpróbálja felvenni a tárolt anyagot (nem sikerül)
	 * */
	public void felveszAnyag(Virologus v) {
	}
	
	/**
	 * Megpróbálja felvenni az itt lévő felszerelést (nem sikerül)
	 * */
	public Vedofelsz felveszVedofelsz() {
		return new Zsak();
	}
}
