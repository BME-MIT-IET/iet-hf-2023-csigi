package vilagtalan_virologusok;/*
* Description
*
*  @author Ákos
*/



/**
 * Különleges hatásokkal rendelkező osztályok absztrakt ősosztálya.
 * */
public abstract class Hatas {

	/**
	 * Agens rákenésekor vagy Vedofelsz felszedésekor hívódik meg, a kezdeti hatásokat valósítja meg
	 * @param v Ki az a Virologus akire érvényesíteni kell a hatásokat
	 */
	public void begin(Virologus v) {
		Skeleton.tmpWriteOutIn("Hatas:begin üres start");
		Skeleton.tmpWriteOutOut("Hatas:begin üres end");
	}


	/**
	 * A begin() ellenpárja, Agens lejártakor vagy Vedofelsz elvesztésekor hívódik meg
	 * "Visszacsinálja", semmissé teszi az Agens/Vedofelsz hatását
	 */
	public void end() {
	}

	/**
	 * @param mivel Milyen Agenssel próbálnak megkenni minket
	 * @param ki Ki azaz melyik virológus próbál megkenni minket
	 * @return Azzal tér vissza hogy megvéd-e minket az adott Vedofelsz vagy Agens attól, hogy megkenjenek
	 * 			true ha megvédett minket és alapból false, ha hagyja a kenést
	 */
	public boolean megkentek(Agens mivel, Virologus ki) {
		Skeleton.tmpWriteOutIn("Hatas:megkentek start");
		Skeleton.tmpWriteOutOut("Hatas:megkentek end");
		return false;
	}
}
