package vilagtalan_virologusok;/*
* Description
*
*  @author
*/


import java.util.ArrayList;

/**
 * Vezeti a játékot, Létrehozza a játékteret és a virológusokat.
 * */
public class Jatek {
	/** A virológusokat tartalmazó lista, ennek sorrendjében hívja a játékosokat */
	private ArrayList<Virologus> virologusok;
	
	/** Milyen genetikai kódok vannak a pályán */
	private ArrayList<Agens> kodok;

	/**
	 * Jelenleg soron lévő játékos indexe
	 * */
	private int activeIndex;

	/**
	 * Játék konstruktora
	 * */
	public Jatek(ArrayList<Agens> kd, ArrayList<Virologus> vir){
		activeIndex = 0;
		virologusok = vir;
		kodok = kd;
	}
	
	/**
	 * A játéktér felépítése, virológusok létrehozása, minden készenlétbe állítása, a játék indítása.
	 * */
	public void startGame() {
	}
	
	/**
	 * Következő sorra kerülő játékost kiválasztja
	 * @author safar
	 * */
	public void kovJatekos() {
		Skeleton.tmpWriteOutIn("Jatek:kovJatekos start");
		activeIndex = (activeIndex + 1) % virologusok.size();
		virologusok.get(activeIndex).tick();
		Skeleton.tmpWriteOutOut("Jatek:kovJatekos end");
	}
	
	/** Lekérdezi a virológus, hogy az őáltala ismert kódok száma vajon megegyezik-e az összes kód számával. */
	public boolean nyerte_e(int i) { return i == kodok.size();
	}
}
