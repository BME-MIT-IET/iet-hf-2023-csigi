package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**
 * Az aminosavak és a nukleotidok (együttes nevükön anyagok) különféle raktárakban szedhetők össze, ezeket jeleníti meg az osztály.
 * @author sisak
 * */
public class Raktar extends Mezo {
	/**
	 * Az anyag fölvételekor hívódik meg, végrehajtja az anyag felvételét.
	 * @author sisak
	 * */
	public void felveszAnyag(Virologus v) {
		Skeleton.tmpWriteOutIn("Raktar:felveszAnyag start");

		Anyag anyg = v.getAnyag();
		anyg.raktar();

		Skeleton.tmpWriteOutOut("Raktar:felveszAnyag end");
	}
}
