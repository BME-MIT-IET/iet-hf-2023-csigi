package vilagtalan_virologusok;


/**
* Olyan ágenst valósít meg, ami „véletlenszerű bolyongásra” kényszeríti
* a virológust. Ilyenkor nem lehet eldönteni, hogy mikor és merre akarunk
* lépni, egy véletlenszerű irányba fogja léptetni a virológust a köre elején.
*
*
*  @author Rádai Ronald
*/
public class Vitustanc extends Agens {
	/**Mennyi anyag kell az előállításához */
	private int ar;

	/**
	 * A megpéldányosított vírustánc referenciája
	 */
	private final Vitustancolo vitustancolo;

	Vitustanc()
	{
		Skeleton.tmpWriteOutIn("Vitustanc:ctor start");
		vitustancolo = new Vitustancolo();
		Skeleton.tmpWriteOutOut("Vitustancolo:ctor end");
	}


	/**
	 * Hozzáad a paraméterben kapott virológus lépésmanageréhez egy vitustáncoló lépést
	 * @param v Ki az a Virologus aki vitustáncolni fog
	 */
	public void begin(Virologus v)
	{
		Skeleton.tmpWriteOutIn("Vitustanc:begin start");
		virologus = v;
		v.addLepes(vitustancolo);
		Skeleton.tmpWriteOutOut("Vitustanc:begin end");
	}
	
	/**
	 * Az ágens lejáratának a kezelése.
	 * Eltávolítja a tárolt referenciát a lépések közül-
	 */
	public void end()
	{
		Skeleton.tmpWriteOutIn("Vitustanc:end start");
		virologus.removeLepes(vitustancolo);
		Skeleton.tmpWriteOutOut("Vitustanc:end end");
	}
	
	/** */
	public Agens duplicate()
	{
		Skeleton.tmpWriteOutIn("Vitustanc:duplicate start");
		Skeleton.tmpWriteOutOut("Vitustanc:duplicate end");
		return new Vitustanc();
	}
}
