package vilagtalan_virologusok;


/**
* Ez a normál lépést megvalósító osztály. Célja, hogy megmondja, hogy a játékos hova léphet.
*
*
*  @author Rádai Ronald
*/
public class Lepes
{

	/**
	 * Visszaadja az adott lépés prioritását.
	 * @return Prioritás
	 */
	public int getPriority() { Skeleton.tmpWriteOutIn("Lepes:getPriority start"); Skeleton.tmpWriteOutOut("Lepes:getPriority end"); return 10; }
	
	/**
	 * Visszadja a to attributumot. (Sima egyszerű lépés megvalósítása)
	 * @param to i. mező, ahova a játékos szeretne lépni
	 * @param n a jelenlegi mező szomszédjainak a számossága
	 * @return A kiválasztott lépés (to értéke)
	 */
	public int lepes(int to, int n)
	{
		Skeleton.tmpWriteOutIn("Lepes:lepes start");
		Skeleton.tmpWriteOutOut("Lepes:lepes end, Return:" + to);
		if(to >= 0 && to < n)
			return to;
		return -1;
	}
}
