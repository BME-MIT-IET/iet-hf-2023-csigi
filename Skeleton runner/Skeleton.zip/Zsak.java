package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**Olyan védőfelszerelés, ami megnöveli az anyagtárolási képességet */
public class Zsak extends Vedofelsz implements Leptetheto {

    /**
     * Tulajdonossal ellátott paraméterű konstruktor
     * @author Vesztergombi
     */
    public Zsak(Virologus v){
        Skeleton.tmpWriteOutIn("Zsak:ctor start");
        tulaj = v;
        v.addVedofelsz(this);
        Skeleton.tmpWriteOutOut("Zsak:ctor end");
    }

    /**
     * Paraméter nélküli konstruktor
     * @author Vesztergombi
     */
    public Zsak(){
        Skeleton.tmpWriteOutIn("Zsak:ctor start");
        Skeleton.tmpWriteOutOut("Zsak:ctor end");
    }

    public void begin(Virologus v){
        Skeleton.tmpWriteOutIn("Zsak:begin start");
        v.getAnyag().maxNovel();
        tulaj = v;
        Skeleton.tmpWriteOutOut("Zsak:begin end");
    }


    public void end(Virologus v){
        Skeleton.tmpWriteOutIn("Zsak:end start");
        v.getAnyag().maxCsokkent();
        tulaj.removeVedofelsz(this);
        Skeleton.tmpWriteOutOut("Zsak:end end");
    }

    @Override
    public void tick() {

    }
}
