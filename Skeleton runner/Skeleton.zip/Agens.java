package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**
 * A különböző hatásokat megvalósító egyedi ágensek közös tulajdonságait és metódusait összefogó ősosztály.
 * */
public abstract class Agens extends Hatas implements Leptetheto {
	/**
	 * Amikor rá van kenve valakire, azt jelzi, hogy még hány körig aktív rajta, minden körben eggyel csökken az értéke
	 * A megtanult ágensekre az értéke int_max
	 * */
	protected int eletek = 5;
	
	/**
	 * Mennyi az ágens anyagköltsége?
	 * */
	protected int ar = 100;
	
	/**
	 * Melyik virológuson aktív éppen.
	 * */
	protected Virologus virologus;
	
	/**
	 * Minden körben csökken egyel, amikor lejár, megszűnik az ágens
	 * @author safar
	 * */
	public void tick() {
		Skeleton.tmpWriteOutIn("Agens:tick start");
		eletek--;
		Skeleton.tmpWriteOutOut("Agens:tick end");
	}


	/**
	 * Getter az Agens anyagárához
	 * @return Egy nemnegatív szám, ami az adott Agens legyártásához szükséges anyagmennyiséget jelenti
	 */
	public int getAr()
	{
		Skeleton.tmpWriteOutIn("Agens:getAr start");
		Skeleton.tmpWriteOutOut("Agens:getAr end");
		return ar;
	}
	
	/**
	 * Létrehoz egy új példányt az Ágensből
	 * */
	public abstract Agens duplicate();
}
