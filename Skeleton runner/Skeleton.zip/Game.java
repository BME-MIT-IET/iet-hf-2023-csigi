package vilagtalan_virologusok;
import java.util.Scanner;
import java.util.ArrayList;


/**
 * A "Game" osztály felelőssége, hogy a tesztek elvégződjenek.
 * Itt történik az osztályok példányosítása, tesztek futtatása
 *
 * @author  everyone
 */
public class Game
{
    public static final int benalepes_priority = 30;
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        boolean next = true;
        while (next)
        {
            System.out.println("Lehetséges tesztek: (exit: 0)\n" +
                    "1: Virológus lép, \n" +
                    "2: Béna lépés, \n" +
                    "3: Vitustanc, majd lejár és sima lépés \n" +
                    "4: Felejtovel kennek\n" +
                    "5: Vedovel kennek\n" +
                    "6: Benitoval kennek\n" +
                    "7: Vitustanccal kennek\n" +
                    "8: nem benult virologus kirablasa \n" +
                    "9: benult vedelem nelkuli virologus kirablasa\n" +
                    "10: benult vedofelszereleses virologus kirablasa \n" +
                    "11: kovetkezo jatekos, nics leptetheto \n" +
                    "12: kovetkezo jatekos, kesztyuval \n" +
                    "13: kovetkezo jatekos, agensekkel\n" +
                    "14: Kenes de rajta Vedo\n" +
                    "15: Kesztyu hatása (megkennek, de Kesztyu van nálad)\n" +
                    "16: Kopeny hatása (megkennek, de Kopeny van rajtad)\n" +
                    "17: kesztyűpingpong\n" +
                    "18: Zsak hatás kezdet\n" +
                    "19: Zsak hatás vége\n" +
                    "20: Anyag felvétel\n" +
                    "21: Védőfelszerelés felvétel \n" +
                    "22: Kód letapogatása\n"
            );
            //Tesztek
            int val = in.nextInt();
            if(val != 0)
                Skeleton.tmpWriteOutIn("Game_Start");
            switch (val)
            {
                case 0:
                   next = false;
                   System.out.println("Bye!");
                   break;
                case 1:
                    Virologus_lep();
                break;
                case 2:
                    Bena_lepes();
                break;
                case 3:
                    Vitustanc_lejar_majd_sima_lepes();
                    break;
                case 4:
                    Felejtovel_kennek();
                    break;
                case 5:
                    Vedovel_kennek();
                    break;
                case 6:
                    Benito_agenssel_kennek();
                    break;
                case 7:
                    Vitustanccal_kennek();
                    break;
                case 8:
                    //nem benult virologus kirablasa
                    Nem_bena_vir_kirablasa();
                    break;
                case 9:
                    // benult vedelem nelkuli virologus kirablasa
                    Bena_vir_kirablasa_nincs_vedofelsz();
                    break;
                case 10:
                    // benult vedofelszereleses virologus kirablasa
                    Bena_vir_kirablasa_van_vedofelsz();
                    break;
                case 11:
                    // kovetkezo jatekos, nics leptetheto
                    Kovetkezo_jatekos_nincs_leptethetoje();
                    break;
                case 12:
                    // kovetkezo jatekos, kesztyuvel
                    Kovetkezo_jatekos_van_kesztyuje();
                    break;
                case 13:
                    // kovetkezo jatekos, agensekkel
                    Kovetkezo_jatekos_vannak_agensei();
                    break;
                case 14:
                    Kenes_de_rajta_vedoagens();
                    break;
                case 15:
                    kesztyuHatasa(); break;
                case 16:
                    kopenyHatasa(); break;
                case 17:
                    kesztyupingpong(); break;
                case 18:
                    zsakHatasKezdet(); break;
                case 19:
                    zsakHatasVege(); break;
                case 20:
                    Anyag_felvetel();break;
                case 21:
                    Vedofelsz_felvetel(); break;
                case 22:
                    Kod_letapogat(); break;

            }
            if(val != 0)
                Skeleton.tmpWriteOutOut("Game_End");
        }
    }

    private static void Kovetkezo_jatekos_vannak_agensei() {
        // init
        ArrayList<Virologus> v13_1 = new ArrayList<>();
        ArrayList<Agens> agens13 = new ArrayList<Agens>();
        agens13.add(new Felejt());
        agens13.add(new Benit());
        agens13.add(new Vedo());
        agens13.add(new Vitustanc());
        v13_1.add(new Virologus(false, new ArrayList<Vedofelsz>(), agens13));
        Jatek j13 = new Jatek(new ArrayList<Agens>(),v13_1);

        // teszt
        j13.kovJatekos();
    }

    private static void Kovetkezo_jatekos_van_kesztyuje() {
        // init
        ArrayList<Virologus> v12_1 = new ArrayList<>();
        ArrayList<Vedofelsz> vedo12 = new ArrayList<Vedofelsz>();
        vedo12.add(new Kesztyu());
        v12_1.add(new Virologus(false, vedo12, new ArrayList<Agens>()));
        Jatek j12 = new Jatek(new ArrayList<Agens>(),v12_1);

        // teszt
        j12.kovJatekos();
    }

    private static void Kovetkezo_jatekos_nincs_leptethetoje() {
        // init
        ArrayList<Virologus> v11_1 = new ArrayList<>();
        v11_1.add(new Virologus());
        Jatek j11 = new Jatek(new ArrayList<Agens>(),v11_1);

        // teszt
        j11.kovJatekos();
    }

    private static void Bena_vir_kirablasa_van_vedofelsz() {
        // init
        Virologus v10_1 = new Virologus();
        ArrayList<Vedofelsz> vedo10 = new ArrayList<Vedofelsz>();
        vedo10.add(new Kesztyu());
        vedo10.add(new Kopeny());
        vedo10.add(new Zsak());
        Virologus v10_2 = new Virologus(true, vedo10, new ArrayList<Agens>());
        for (Vedofelsz fsz : vedo10) { fsz.begin(v10_2); }

        // teszt
        v10_1.tamaddMeg(v10_2);
    }

    private static void Bena_vir_kirablasa_nincs_vedofelsz() {
        // init
        Virologus v9_1 = new Virologus();
        Virologus v9_2 = new Virologus(true, new ArrayList<Vedofelsz>(), new ArrayList<Agens>());

        // teszt
        v9_1.tamaddMeg(v9_2);
    }

    private static void Nem_bena_vir_kirablasa() {
        // init
        Virologus v8_1 = new Virologus();
        Virologus v8_2 = new Virologus();

        // teszt
        v8_1.tamaddMeg(v8_2);
    }

    private static void kesztyuHatasa(){
        //init
        Mezo m = new Mezo();
        Virologus v15_1 = new Virologus(m);
        Virologus v15_2 = new Virologus(m);
        Zsak zs = new Zsak(v15_2);
        Kesztyu ke = new Kesztyu(v15_2);

        //test
        var itt = m.ittLevok();
        if (itt.contains(v15_2))
            v15_1.kendMeg(v15_2, new Benit());
    }

    private static void kopenyHatasa(){
        //init
        Mezo m = new Mezo();
        Virologus v16_1 = new Virologus(m);
        Virologus v16_2 = new Virologus(m);
        Zsak zs = new Zsak(v16_2);
        Kopeny ko = new Kopeny(v16_2);

        //test
        var itt = m.ittLevok();
        if (itt.contains(v16_2))
            v16_1.kendMeg(v16_2, new Benit());
    }

    private static void kesztyupingpong(){
        //init
        Mezo m = new Mezo();
        Virologus v17_1 = new Virologus(m);
        Virologus v17_2 = new Virologus(m);
        Kesztyu ke1 = new Kesztyu(v17_1);
        Kesztyu ke2 = new Kesztyu(v17_2);

        //test
        var itt = m.ittLevok();
        if (itt.contains(v17_2))
            v17_1.kendMeg(v17_2, new Benit());
    }

    private static void zsakHatasKezdet(){
        Virologus v = new Virologus();
        Zsak zs = new Zsak(v);
    }

    private static void zsakHatasVege(){
        Virologus v = new Virologus();
        Zsak zs = new Zsak(v);
        zs.end(v);
    }

    private static void Virologus_lep()
    {
        Mezo jel = new Mezo();
        Mezo m1 = new Mezo();
        Mezo m2 = new Mezo();
        Mezo m3 = new Mezo();
        Mezo m4 = new Mezo();
        ArrayList<Mezo> list = new ArrayList<>();
        list.add(m1);
        list.add(m2);
        list.add(m3);
        list.add(m4);
        jel.set_szomszedok(new ArrayList<Mezo>(list));
        Virologus v = new Virologus(jel);
        v.lep(1);
    }

    private static void Bena_lepes()
    {
        Mezo jel = new Mezo();
        Mezo m1 = new Mezo();
        Mezo m2 = new Mezo();
        Mezo m3 = new Mezo();
        Mezo m4 = new Mezo();
        ArrayList<Mezo> list = new ArrayList<>();
        list.add(m1);
        list.add(m2);
        list.add(m3);
        list.add(m4);
        jel.set_szomszedok(new ArrayList<Mezo>(list));
        Virologus v2 = new Virologus(jel);
        Benit ba = new Benit();
        //new Virologus().kendMeg(v2, ba);
        ba.begin(v2);
        v2.lep(1);
    }

    private static void Vitustanc_lejar_majd_sima_lepes()
    {
        Mezo jel = new Mezo();
        Mezo m1 = new Mezo();
        Mezo m2 = new Mezo();
        Mezo m3 = new Mezo();
        Mezo m4 = new Mezo();
        ArrayList<Mezo> list = new ArrayList<>();
        list.add(m1);
        list.add(m2);
        list.add(m3);
        list.add(m4);
        jel.set_szomszedok(new ArrayList<Mezo>(list));
        ArrayList<Mezo> lists = new ArrayList<>();
        lists.add(jel);
        m1.set_szomszedok(lists);
        m2.set_szomszedok(lists);
        m3.set_szomszedok(lists);
        m4.set_szomszedok(lists);
        Virologus v3 = new Virologus(jel);
        Vitustanc va = new Vitustanc();
        va.begin(v3);
        v3.lep(2);
        v3.tick();
        va.tick();
        va.end();
        v3.lep(0);
    }

    private static void Felejtovel_kennek()
    {
        ArrayList<Agens> agensek = new ArrayList<Agens>();
        agensek.add(new Benit()); agensek.add(new Vedo());
        Virologus v1 = new Virologus(); Virologus v2 = new Virologus(agensek); Felejt f = new Felejt();
        v1.kendMeg(v2, f);
    }

    private static void Vedovel_kennek()
    {
        Virologus v1 = new Virologus(); Virologus v2 = new Virologus(); Vedo ved = new Vedo();
        v1.kendMeg(v2, ved);
    }

    private static void Benito_agenssel_kennek()
    {
        Virologus v1 = new Virologus(); Virologus v2 = new Virologus(); Benit benit = new Benit();
        v1.kendMeg(v2, benit);
    }

    private static void Vitustanccal_kennek() {
        Virologus v1 = new Virologus(); Virologus v2 = new Virologus(); Vitustanc vt = new Vitustanc();
        v1.kendMeg(v2, vt);
    }

    private static void Kenes_de_rajta_vedoagens()
    {
        //init
        ArrayList<Agens> agens = new ArrayList<>();
        ArrayList<Vedofelsz> vedofelsz = new ArrayList<>();
        agens.add(new Vedo());
        Virologus v1 = new Virologus(false, vedofelsz, agens);
        Virologus v2 = new Virologus();

        //test
        v2.kendMeg(v1, new Felejt());
    }

    /**
     * Anyag felvételét tesztelő függvény
     * @author sisak
     */
    private static void Anyag_felvetel(){
        Skeleton.tmpWriteOutMsg("---Init:start---");
        Raktar r = new Raktar();
        Virologus v = new Virologus(r);
        Skeleton.tmpWriteOutMsg("---Init:end---\n");

        v.addAnyag();
    }

    /**
     * Védőfelszerelés felvételét tesztelő függvény
     * @author sisak
     */
    private static void Vedofelsz_felvetel(){
        Skeleton.tmpWriteOutMsg("---Init:start---");
        Vedofelsz vdf = new Kopeny();
        Ovohely ov = new Ovohely(vdf);
        Virologus v = new Virologus(ov);
        Skeleton.tmpWriteOutMsg("---Init:end---\n");

        v.addVedofelsz();
    }

    /**
     * Kód-letapogatást tesztelő függvény
     * @author sisak
     */
    private static void Kod_letapogat(){
        Skeleton.tmpWriteOutMsg("---Init:start---");
        Agens kod = new Benit();
        Labor lb = new Labor(kod);
        Virologus v = new Virologus(lb);
        Skeleton.tmpWriteOutMsg("---Init:end---\n");

        v.tapogasdLe();

    }
}