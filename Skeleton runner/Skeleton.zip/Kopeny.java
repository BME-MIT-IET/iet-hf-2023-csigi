package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**
 * Védőköpenyt reprezentáló osztály, a köpeny az ágenseket 82,3%-os hatásfokkal tartja távol.
 * */
public class Kopeny extends Vedofelsz {

	/**
	 * Tulajdonossal ellátott paraméterű konstruktor
	 * @author Vesztergombi
	 */
	public Kopeny(Virologus v){
		Skeleton.tmpWriteOutIn("Kopeny:ctor start");
		tulaj = v;
		v.addVedofelsz(this);
		Skeleton.tmpWriteOutOut("Kopeny:ctor end");
	}

	/**
	 * Paraméter nélküli konstruktor
	 * @author Vesztergombi
	 */
	public Kopeny(){
		Skeleton.tmpWriteOutIn("Kopeny:ctor start");
		Skeleton.tmpWriteOutOut("Kopeny:ctor end");
	}

	/**
	 * A köpenyt viselő virológus megkenése
	 * @param mivel Milyen Agenssel próbálnak megkenni minket
	 * @param ki Ki azaz melyik virológus próbál megkenni minket
	 * @return Ki tudta-e védeni a megkenést
	 * @author Vesztergombi
	 */
	@Override
    public boolean megkentek(Agens mivel, Virologus ki) {
		Skeleton.tmpWriteOutIn("Kopeny:megkentek start");
		if (Skeleton.tmpAskQuestion("Beleesik a 82,3%-os valószínűségbe? (y)")){
			Skeleton.tmpWriteOutOut("Kopeny:megkentek end");
			return true;
		}
		Skeleton.tmpWriteOutOut("Kopeny:megkentek end");
		return false;
	}

	/** */
	@Override
	public void tick() {

	}
}
