package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**
 * Labor típusú mezőt reprezentáló osztály.
 * */
public class Labor extends Mezo {

	/**
	 * Konstruktor
	 * @param a A laborban levo agens
	 * @authore sisak
	 */
	public Labor(Agens a){
		Skeleton.tmpWriteOutIn("Labor:ctor start");

		kod = a;

		Skeleton.tmpWriteOutOut("Labor:ctor end");
	}

	/**Mely genetikai kód van a laborban */
	private Agens kod;
	
	/**A virologus letapogatja a genetikai kódot
	 * @return A laborban lévő genetikai kód */
	public Agens letapogat() {
		Skeleton.tmpWriteOutIn("Labor:letapogat start");
		Skeleton.tmpWriteOutOut("Labor:letapogat end");
		return kod;
	}
}
