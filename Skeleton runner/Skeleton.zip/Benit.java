package vilagtalan_virologusok;
/**
* Egy olyan ágenst valósít meg, ami lebénítja a virológust,
* aki a bénultság ideje alatt nem tud akciókat végrehajtani,
* és célpontja lehet rablásoknak.
*
*
*  @author Rádai Ronald
*/
public class Benit extends Agens {
	/**
	 * Mennyi anyag kell az elkészítéséhez
	 * */
	private int ar;

	/**
	 * A megpéldányosított bena referenciája
	 */
	private final Bena bena;

	/**
	 * Alap konstruktor
	 */
	Benit()
	{
		Skeleton.tmpWriteOutIn("Benit:ctor start");
		bena = new Bena();
		Skeleton.tmpWriteOutOut("Benit:ctor end");
	}

	/**
	 * Hozzáad a paraméterben kapott virológus lépésmanageréhez egy bena lépést
	 * @param v Ki az a Virologus aki le fog bénulni
	 */
	public void begin(Virologus v)
	{
		Skeleton.tmpWriteOutIn("Benit:begin start");
		v.addLepes(bena);
		Skeleton.tmpWriteOutOut("Benit:begin end");
	}

	/**
	 * Az ágens lejáratának a kezelése.
	 * Eltávolítja a tárolt referenciát a lépések közül-
	 */
	public void end()
	{
		Skeleton.tmpWriteOutIn("Benit:end start");
		virologus.removeLepes(bena);
		Skeleton.tmpWriteOutOut("Benit:end end");
	}
	
	/**
	 *
	 * */
	public Agens duplicate()
	{
		Skeleton.tmpWriteOutIn("Benit:duplicate start");
		Skeleton.tmpWriteOutOut("Benit:duplicate end");
		return new Benit();
	}
}
