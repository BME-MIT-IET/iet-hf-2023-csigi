package vilagtalan_virologusok;
import java.util.Scanner;


/**
 * A "Skeleton" osztály a testek elvégzésében segítkezik,
 * az osztály felelőssége, hogy kommunikál a felhasználóval, illetve
 * beljebb - kiljebb kezdi az adott tartalmat.
 *
 * @author everyone
 */
public class Skeleton
{
    private static int depth = 0;

    /**
     * Függvény a betolások megoldására
     */
    private  static void bekezd()
    {
        for(int i = 0; i < Skeleton.depth; ++i)
            System.out.print('\t');
    }

    /**
     * Függvényhívás kezdődik, ezért beljebb kezdi az előzőnél.
     * kiírja ezen felül az üzenetet is, amit paraméterként megkap
     * @param msg üzenet
     */
    public static void tmpWriteOutIn(String msg)
    {
        bekezd();
        System.out.println(msg);
        ++depth;
    }

    /**
     * Függvényhívás végződik, ezért kiljebb kezdi az előzőnél.
     * kiírja ezen felül az üzenetet is, amit paraméterként megkap
     * @param msg üzenet
     */
    public static void tmpWriteOutOut(String msg)
    {
        --depth;
        bekezd();
        System.out.println(msg);
    }

    /**
     * Az adott üzenetet kiírja beljebb kezdve a képernyőre.
     * @param msg üzenet
     */
    public static void tmpWriteOutMsg(String msg)
    {
        bekezd();
        System.out.println(msg);
    }

    /*
    * A megadott paraméterű üzenettel kérdez egyet a felhasználótól.
    * Eldöntendő kérdés, y-t vagy n-t fogad el.
    * @return y válasz esetén true, n válasz esetén false
    * */
    public static boolean tmpAskQuestion(String msg)
    {
        bekezd();
        System.out.println(msg + " y/n");
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            char answer = scan.next().charAt(0);
            if(answer == 'y') { return true;}
            if(answer == 'n') { return false;}
        }
    }
}
