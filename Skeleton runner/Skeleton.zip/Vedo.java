package vilagtalan_virologusok;/*
* Description
*
*  @author Ákos
*/



/** Egy olyan ágenst valósít meg, ami megvédi a virológust további ágensek rákenésétől. */
public class Vedo extends Agens {
	/**Mennyi anyag kell az elkészítéséhez */
	private int ar;


	/**
	 * @param mivel Milyen Agenssel próbálnak megkenni minket
	 * @param ki    Ki azaz melyik virológus próbál megkenni minket
	 * @return true-val tér vissza, hisz sikeresen megvéd minket a kenéstől
	 * @author Ákos
	 */
	@Override
	public boolean megkentek(Agens mivel, Virologus ki)
	{
		Skeleton.tmpWriteOutIn("Vedo:megkentek start");
		Skeleton.tmpWriteOutOut("Vedo:megkentek end");
		return true;
	}
	
	/**
	 *
	 * */
	public Agens duplicate()
	{
		Skeleton.tmpWriteOutIn("Vedo:duplicate start");
		Skeleton.tmpWriteOutOut("Vedo:duplicate end");
		return new Vedo();
	}
}
