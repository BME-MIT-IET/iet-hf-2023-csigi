package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/**Az interfészt megvalósító osztályok öregíthetőek, minden körben öregedhetnek */
public interface Leptetheto {
	/**Ez a metódus öregíti az interfészt megvalósító objektumokat. */
	public void tick();
}
