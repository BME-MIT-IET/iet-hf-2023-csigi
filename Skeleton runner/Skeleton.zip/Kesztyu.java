package vilagtalan_virologusok;/*
* Description
*
*  @author
*/



/** A kesztű védőfelszerelést reprezentálja.
 * Ezzel a felkent ágens a kenőre visszadobható.
 * Minden körben korlátos számban dobható vissza ágens.*/
public class Kesztyu extends Vedofelsz {

	/**
	 * Egy körben hány visszadobás engedélyezett
	 * */
	private int hanyszorDefault;

	/**Hányszor tud még kenést visszadobni az adott körben. */
	private int hanyszor;

	/**
	 * Tulajdonossal ellátott paraméterű konstruktor
	 * @author Vesztergombi
	 */
	public Kesztyu(Virologus v){
		Skeleton.tmpWriteOutIn("Kesztyu:ctor start");
		tulaj = v;
		v.addVedofelsz(this);
		Skeleton.tmpWriteOutOut("Kesztyu:ctor end");
	}

	/**
	 * Paraméter nélküli konstruktor
	 * @author Vesztergombi
	 */
	public Kesztyu(){
		Skeleton.tmpWriteOutIn("Kesztyu:ctor start");
		Skeleton.tmpWriteOutOut("Kesztyu:ctor end");
	}

	/**
	 * Megkenés hatására a Kesztyu által végbemenő események
	 * @param mivel Milyen Agenssel próbálnak megkenni minket
	 * @param ki Ki azaz melyik virológus próbál megkenni minket
	 * @return Ki tudta-e védeni a megkenést
	 * @author Vesztergombi
	 */
	@Override
    public boolean megkentek(Agens mivel, Virologus ki) {
		Skeleton.tmpWriteOutIn("Kesztyu:megkentek start");
		if (Skeleton.tmpAskQuestion("Van még élete a kesztyűnek? (y, ha többször kérdezi: 3 db y után 1 db n)")){
			boolean b = ki.megken(ki, mivel);
			Skeleton.tmpWriteOutOut("Kesztyu:megkentek end");
			return !b;		//Ha az ellenfél ki tudta védeni, akkor én nem tudtam kivédeni, és fordítva
		}
		Skeleton.tmpWriteOutOut("Kesztyu:megkentek end");
		return false;
	}

	/**
	 * Az adott körre visszaállítja a hátralévő lehetséges visszadobások számát az alapértelmezettre
	 * @author safar
	 * */
	public void tick() {
		Skeleton.tmpWriteOutIn("Kesztyu:tick start");
		hanyszor = hanyszorDefault;
		Skeleton.tmpWriteOutOut("Kesztyu:tick end");
	}
}
